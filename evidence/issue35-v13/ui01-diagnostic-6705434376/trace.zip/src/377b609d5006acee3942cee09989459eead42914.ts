import { defaultDisplayPreferences } from '../src/canonical/displayPreferences'
import { readFileSync } from 'node:fs'
import { readCanonicalState } from './helpers/state'
import { canonicalFixture } from '../src/canonical/fixtures'
import { expect, test, type Page } from '@playwright/test'

test.use({ viewport: { width: 360, height: 800 } })

async function seed(page: Page, fixture = canonicalFixture) {
  await page.clock.setFixedTime(new Date('2026-09-24T12:00:00+09:00'))
  await page.goto('/')
  await page.evaluate(async data => {
    const db = await new Promise<IDBDatabase>((resolve, reject) => {
      const request = indexedDB.open('training-check', 7)
      request.onsuccess = () => resolve(request.result)
      request.onerror = () => reject(request.error)
    })
    await new Promise<void>((resolve, reject) => {
      const tx = db.transaction(['canonical', 'cutover'], 'readwrite')
      tx.objectStore('canonical').put(data, 'app')
      tx.objectStore('cutover').put({ authoritative: true, establishedAt: '2026-09-24T00:00:00+09:00' }, 'state')
      tx.oncomplete = () => resolve()
      tx.onabort = () => reject(tx.error)
    })
    db.close()
  }, fixture)
  await page.reload()
  await expect(page.getByRole('heading', { name: '今週の実施メニュー' })).toBeVisible()
}

test('UI-01 and UI-02: independent sort drafts and fixed settings description', async ({ page }) => {
  const fixture = {
    ...structuredClone(canonicalFixture),
    trainingItems: canonicalFixture.trainingItems.map(item => ({ ...item, managementMode: 'MAN' as const })),
    menus: canonicalFixture.menus.map(menu => ({ ...menu, managementMode: 'MAN' as const })),
    displayPreferences: structuredClone(defaultDisplayPreferences),
    appliedProposalIds: [],
  }
  await seed(page, fixture)
  await page.getByRole('button', { name: '共通メニュー' }).click()
  await page.getByRole('button', { name: '設定', exact: true }).click()
  const display = page.getByRole('button', { name: /^表示設定/ })
  await expect(display.locator('small')).toHaveText('ソート順など、画面表示に関する設定')
  await display.locator('small').evaluate(node => node.style.fontSize = '24px')
  await expect.poll(() => display.evaluate(node => node.scrollWidth <= node.clientWidth)).toBe(true)
  await display.locator('small').click()
  const defaultSort = page.getByRole('region', { name: 'Default', exact: true })
  const optionSort = page.getByRole('region', { name: 'Option', exact: true })
  const rows = defaultSort.locator('.sort-priority-row')
  const labels = rows.locator('span:first-child')
  const original = await labels.allTextContents()
  const option = optionSort.locator('.sort-priority-row span:first-child')
  const originalOption = await option.allTextContents()
  const moveOption = optionSort.getByRole('button', { name: /を上へ/ }).last()
  await moveOption.focus()
  await expect(moveOption).toBeFocused()
  await page.keyboard.press('Enter')
  await expect(option).toHaveText([originalOption[0], originalOption[2].replace(/^3/, '2'), originalOption[1].replace(/^2/, '3')])
  await page.getByRole('button', { name: /戻る/ }).click()
  await display.click()
  await expect(option).toHaveText(originalOption)
  expect(original).toHaveLength(3)
  const handle = rows.last().locator('.sort-drag-handle')
  const destination = rows.first().locator('.sort-drag-handle')
  const drag = async () => {
    const source = await handle.boundingBox()
    const target = await destination.boundingBox()
    await page.mouse.move(source!.x + source!.width / 2, source!.y + source!.height / 2)
    await page.mouse.down()
    await page.mouse.move(target!.x + target!.width / 2, target!.y + target!.height / 2, { steps: 8 })
    await page.mouse.up()
  }
  await drag()
  const reordered = [original[2], original[0], original[1]].map((text, i) => text.replace(/^\d/, String(i + 1)))
  await expect(labels).toHaveText(reordered)
  await expect(option).toHaveText(originalOption)
  await expect.poll(() => page.evaluate(() => document.documentElement.scrollWidth)).toBe(360)
  await page.getByRole('button', { name: /戻る/ }).click()
  await display.click()
  await expect(labels).toHaveText(original)
  await drag()
  await page.getByRole('button', { name: '設定を保存' }).click()
  await display.click()
  await expect(labels).toHaveText(reordered)
  await expect(option).toHaveText(originalOption)
  const saved = {
    ...fixture, displayPreferences: { ...fixture.displayPreferences, defaultSort: {
      ...fixture.displayPreferences.defaultSort, priority: ['bodyRegion', 'recommendedDay', 'completion'],
    } },
  }
  expect(await readCanonicalState(page)).toEqual(saved)
  await page.reload()
  expect(await readCanonicalState(page)).toEqual(saved)
})

test('UI-04: removes the decorative glyph while preserving history and Run entry', async ({ page }) => {
  await seed(page)
  await page.getByRole('button', { name: '＋ 追加トレーニングを登録' }).click()
  const before = await readCanonicalState(page)
  await page.getByRole('combobox', { name: '部位' }).selectOption('胸')
  await page.getByRole('checkbox', { name: 'Optionソート' }).check()
  const row = page.locator('[data-training-item-id="item-1"] > button')
  await expect(row).not.toContainText('›')
  await expect(row.locator('.item-history')).toHaveText(/^(?:[●○]｜?){14}$/)
  await expect.poll(() => page.evaluate(() => document.documentElement.scrollWidth)).toBe(360)
  await row.click()
  await expect(page.getByRole('heading', { name: 'ダンベルプレス', exact: true })).toBeVisible()
  expect(await readCanonicalState(page)).toEqual(before)
})

test('UI-03: cancel preserves Trainer authority, confirmation saves standard and releases it', async ({ page }) => {
  const fixture = structuredClone(canonicalFixture)
  fixture.trainingItems[0].managementMode = 'TRAINER'
  fixture.sessions[0].date = '2026-09-01'
  fixture.sessions[0].performedAt = '2026-09-01T09:00:00+09:00'
  fixture.sessions.push({
    ...structuredClone(fixture.sessions[0]), id: 'session-older',
    date: '2026-08-31', performedAt: '2026-08-31T09:00:00+09:00', memo: '過去の合成メモ',
  })
  await seed(page, fixture)
  await page.locator('.weekday-dropdown-trigger').click()
  await page.getByRole('button', { name: '全ON', exact: true }).click()
  await page.locator('.weekday-dropdown-trigger').click()
  await page.locator('[data-menu-entry-id="entry-1"]').click()
  const save = page.getByRole('button', { name: 'この設定を登録' })
  await page.getByRole('button', { name: '重量を1kg増やす' }).click()
  await page.getByLabel('今回メモ').fill('保存対象外の合成メモ')
  const confirmation = 'この設定を標準設定として登録すると、トレーナー管理を解除します。当回メモは標準設定へ保存しません。登録しますか？'
  const read = () => page.evaluate(async () => {
    const db = await new Promise<IDBDatabase>((resolve, reject) => {
      const request = indexedDB.open('training-check', 7)
      request.onsuccess = () => resolve(request.result)
      request.onerror = () => reject(request.error)
    })
    try {
      return await new Promise<typeof canonicalFixture>((resolve, reject) => {
        const request = db.transaction('canonical').objectStore('canonical').get('app')
        request.onsuccess = () => resolve(request.result)
        request.onerror = () => reject(request.error)
      })
    } finally { db.close() }
  })
  const click = async (accept: boolean, expected = confirmation) => {
    const dialog = page.waitForEvent('dialog')
    const action = save.click()
    const prompt = await dialog
    const message = prompt.message()
    if (accept) await prompt.accept()
    else await prompt.dismiss()
    await action
    expect(message).toBe(expected)
  }
  await click(false)
  expect(await read()).toEqual(fixture)
  await page.evaluate(() => {
    const original = IDBObjectStore.prototype.put
    IDBObjectStore.prototype.put = function (...args) {
      if (this.name === 'canonical' && args[1] === 'app') {
        IDBObjectStore.prototype.put = original
        throw new DOMException('Synthetic pre-commit failure', 'QuotaExceededError')
      }
      return original.apply(this, args)
    }
  })
  await click(true)
  await expect(page.getByText('標準設定を保存できません。入力値を確認してください。')).toBeVisible()
  expect(await read()).toEqual(fixture)
  await click(true)
  await expect.poll(async () => (await read()).trainingItems[0]).toEqual({
    ...fixture.trainingItems[0], managementMode: 'MAN', weight: 19,
  })
  const stored = await read()
  await click(false, 'この設定を標準設定として登録しますか？当回メモは標準設定へ保存しません。')
  expect(await read()).toEqual(stored)
  expect(stored.sessions).toEqual(fixture.sessions)
  expect(stored.trainingItemSettingChanges).toHaveLength(fixture.trainingItemSettingChanges.length + 1)
})
test('UI-01: touch drag reorders only its own section', async ({ browser }) => {
  const context = await browser.newContext({ baseURL: 'http://127.0.0.1:4173', viewport: { width: 360, height: 620 }, hasTouch: true, isMobile: true, timezoneId: 'Asia/Tokyo' })
  try {
    const page = await context.newPage()
    await seed(page)
    await page.getByRole('button', { name: '共通メニュー' }).tap()
    await page.getByRole('button', { name: '設定', exact: true }).tap()
    await page.getByRole('button', { name: /^表示設定/ }).tap()
    const handles = page.getByRole('region', { name: 'Default', exact: true }).locator('.sort-drag-handle')
    const beforeOption = await page.getByRole('region', { name: 'Option', exact: true }).textContent()
    const coordinates = async (index: number) => {
      const box = await handles.nth(index).boundingBox()
      return { x: box!.x + box!.width / 2, y: box!.y + box!.height / 2 }
    }
    const cdp = await context.newCDPSession(page)
    await cdp.send('Input.dispatchTouchEvent', { type: 'touchStart', touchPoints: [await coordinates(2)] })
    await cdp.send('Input.dispatchTouchEvent', { type: 'touchMove', touchPoints: [await coordinates(0)] })
    await cdp.send('Input.dispatchTouchEvent', { type: 'touchEnd', touchPoints: [] })
    await expect(handles.first().locator('..').locator('span:first-child')).toHaveText('1 部位')
    expect(await page.getByRole('region', { name: 'Option', exact: true }).textContent()).toBe(beforeOption)
  } finally { await context.close() }
})

test('UI-03: post-commit read-back fault blocks Trainer standard retry and preserves Session', async ({ page }, info) => {
  const fixture = structuredClone(canonicalFixture)
  fixture.trainingItems[0].managementMode = 'TRAINER'
  fixture.sessions[0].date = '2026-09-01'
  fixture.sessions[0].performedAt = '2026-09-01T09:00:00+09:00'
  await seed(page, fixture)
  await page.locator('.weekday-dropdown-trigger').click()
  await page.getByRole('button', { name: '全ON', exact: true }).click()
  await page.locator('.weekday-dropdown-trigger').click()
  await page.locator('[data-menu-entry-id="entry-1"]').click()
  await page.getByRole('button', { name: '重量を1kg増やす' }).click()
  await page.evaluate(() => {
    const probe = { writes: 0, committed: false, injected: false }
    Object.assign(window, { trainerStandardProbe: probe })
    const put = IDBObjectStore.prototype.put
    const get = IDBObjectStore.prototype.get
    IDBObjectStore.prototype.put = function (...args) {
      if (this.name === 'canonical') {
        probe.writes++
        this.transaction.addEventListener('complete', () => { probe.committed = true }, { once: true })
      }
      return put.apply(this, args)
    }
    IDBObjectStore.prototype.get = function (...args) {
      if (this.name === 'canonical' && this.transaction.mode === 'readonly' && probe.writes === 1 && !probe.injected) {
        probe.injected = true
        throw new Error('synthetic Trainer standard independent read-back fault')
      }
      return get.apply(this, args)
    }
  })
  page.once('dialog', dialog => dialog.accept())
  await page.getByRole('button', { name: 'この設定を登録' }).click()
  await expect(page.getByRole('alert')).toContainText('保存結果を確認できません。再実行せず')
  await expect(page.getByRole('button', { name: 'この設定を登録' })).toHaveCount(0)
  await expect(page.getByText('標準設定を保存しました。', { exact: true })).toHaveCount(0)
  const probe = await page.evaluate(() => Reflect.get(window, 'trainerStandardProbe'))
  expect(probe).toEqual({ writes: 1, committed: true, injected: true })
  const saved = await readCanonicalState(page)
  expect(saved.trainingItems).toEqual([{ ...fixture.trainingItems[0], managementMode: 'MAN', weight: 19 }, ...fixture.trainingItems.slice(1)])
  expect(saved.sessions).toEqual(fixture.sessions)
  expect(saved.trainingItemSettingChanges).toHaveLength(fixture.trainingItemSettingChanges.length + 1)
  const event = page.waitForEvent('download')
  await page.getByRole('button', { name: '診断情報を保存' }).click()
  const diagnostic = JSON.parse(readFileSync((await (await event).path())!, 'utf8'))
  expect(diagnostic).toMatchObject({ stage: 'standard-setting', code: 'UNKNOWN_HELD' })
  await page.getByRole('button', { name: '保存状態を再読込' }).click()
  await expect(page.getByRole('heading', { name: '今週の実施メニュー' })).toBeVisible()
  expect(await readCanonicalState(page)).toEqual(saved)
  await info.attach('trainer-standard-unknown', { body: JSON.stringify({ probe, diagnostic, before: fixture, saved }), contentType: 'application/json' })
})


test('UI-01: touch handle reorder does not scroll a vertically scrolled settings page', async ({ browser, baseURL }, info) => {
  const context = await browser.newContext({ baseURL, viewport: { width: 360, height: 400 }, hasTouch: true, isMobile: true, timezoneId: 'Asia/Tokyo' })
  try {
    const page = await context.newPage()
    const fixture = {
      ...structuredClone(canonicalFixture),
      trainingItems: canonicalFixture.trainingItems.map(item => ({ ...item, managementMode: 'MAN' as const })),
      menus: canonicalFixture.menus.map(menu => ({ ...menu, managementMode: 'MAN' as const })),
      displayPreferences: structuredClone(defaultDisplayPreferences),
      appliedProposalIds: [],
    }
    await seed(page, fixture)
    await page.getByRole('button', { name: '共通メニュー' }).tap()
    await page.getByRole('button', { name: '設定', exact: true }).tap()
    const display = page.getByRole('button', { name: /^表示設定/ })
    await display.tap()
    const defaultSort = page.getByRole('region', { name: 'Default', exact: true })
    const option = page.getByRole('region', { name: 'Option', exact: true })
    const beforeOption = await option.textContent()
    const cdp = await context.newCDPSession(page)
    const scrollY = () => page.evaluate(() => window.scrollY)
    const drag = async () => {
      const handles = defaultSort.locator('.sort-drag-handle')
      await handles.last().scrollIntoViewIfNeeded()
      const initialScroll = await scrollY()
      expect(initialScroll).toBeGreaterThan(0)
      const point = async (index: number) => {
        const box = (await handles.nth(index).boundingBox())!
        const y = box.y + box.height / 2
        expect(y).toBeGreaterThan(0)
        expect(y).toBeLessThan(400)
        return { x: box.x + box.width / 2, y }
      }
      await cdp.send('Input.dispatchTouchEvent', { type: 'touchStart', touchPoints: [await point(2)] })
      await cdp.send('Input.dispatchTouchEvent', { type: 'touchMove', touchPoints: [await point(0)] })
      await cdp.send('Input.dispatchTouchEvent', { type: 'touchEnd', touchPoints: [] })
      expect(await scrollY()).toBe(initialScroll)
      await expect(handles.first().locator('..').locator('span:first-child')).toHaveText('1 部位')
      expect(await option.textContent()).toBe(beforeOption)
      return initialScroll
    }
    const cancelScroll = await drag()
    await page.getByRole('button', { name: /戻る/ }).tap()
    expect(await readCanonicalState(page)).toEqual(fixture)
    await display.tap()
    const saveScroll = await drag()
    const save = page.getByRole('button', { name: '設定を保存' })
    const before = await readCanonicalState(page)
    const draft = await page.locator('.display-preference-section').evaluateAll(sections => sections.map(section => ({
      priority: [...section.querySelectorAll('.sort-priority-row span:first-child')].map(row => row.textContent?.replace(/^\d+ /, '')),
      direction: section.querySelector('input:checked')?.parentElement?.textContent,
    })))
    const probeBefore = await save.evaluate(button => {
      const probe = { events: [] as object[], idb: [] as object[] }
      Object.assign(window, { ui01Probe: probe })
      for (const type of ['touchstart', 'touchend', 'pointerdown', 'pointerup', 'click']) {
        document.addEventListener(type, event => {
          const input = event as MouseEvent & { changedTouches?: TouchList }
          const touch = input.changedTouches?.[0]
          const x = touch?.clientX ?? input.clientX
          const y = touch?.clientY ?? input.clientY
          probe.events.push({ type, x, y, trusted: event.isTrusted,
            target: (event.target as Element)?.textContent?.trim().slice(0, 100),
            hit: document.elementFromPoint(x, y)?.textContent?.trim().slice(0, 100),
            saveTarget: button.contains(event.target as Node),
          })
        }, { capture: true, passive: true })
      }
      const get = IDBObjectStore.prototype.get
      const put = IDBObjectStore.prototype.put
      IDBObjectStore.prototype.get = function (...args) {
        probe.idb.push({ action: 'get', store: this.name, mode: this.transaction.mode })
        return get.apply(this, args)
      }
      IDBObjectStore.prototype.put = function (...args) {
        probe.idb.push({ action: 'put', store: this.name, mode: this.transaction.mode })
        for (const type of ['complete', 'abort', 'error']) {
          this.transaction.addEventListener(type, () => probe.idb.push({ action: type, error: this.transaction.error?.message }), { once: true })
        }
        return put.apply(this, args)
      }
      return { disabled: (button as HTMLButtonElement).disabled,
        pending: [...document.querySelectorAll('.display-preference-section fieldset')].some(node => (node as HTMLFieldSetElement).disabled),
        rect: button.getBoundingClientRect().toJSON(), scroll: window.scrollY }
    })
    await save.tap()
    const expected = {
      ...fixture, displayPreferences: { ...fixture.displayPreferences, defaultSort: {
        ...fixture.displayPreferences.defaultSort, priority: ['bodyRegion', 'recommendedDay', 'completion'],
      } },
    }
    let outcome: unknown
    try { await expect.poll(() => readCanonicalState(page)).toEqual(expected) } catch (error) { outcome = String(error) }
    const after = await readCanonicalState(page)
    const browserState = await page.evaluate(() => ({
      probe: Reflect.get(window, 'ui01Probe'),
      route: [...document.querySelectorAll('h1')].map(node => node.textContent),
      notices: [...document.querySelectorAll('[role=status],[role=alert]')].map(node => node.textContent),
      savePresent: [...document.querySelectorAll('button')].some(node => node.textContent === '設定を保存'),
      pending: [...document.querySelectorAll('.display-preference-section fieldset')].some(node => (node as HTMLFieldSetElement).disabled),
      scroll: window.scrollY,
    }))
    await page.reload()
    const reloaded = await readCanonicalState(page)
    await info.attach('ui01-diagnostic', { body: JSON.stringify({
      cancelScroll, saveScroll, draft, validSortObservable: !probeBefore.disabled && !probeBefore.pending,
      probeBefore, browserState, before, expected, after, reloaded, outcome,
    }, null, 2), contentType: 'application/json' })
    expect(after).toEqual(expected)
    expect(reloaded).toEqual(expected)
  } finally { await context.close() }
})
